package com.poolvision.overlay

import android.graphics.Bitmap
import android.graphics.PointF
import android.graphics.RectF
import org.opencv.android.Utils
import org.opencv.core.*
import org.opencv.imgproc.Imgproc
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Computer vision murni dari screenshot: tidak menyentuh proses/memori game.
 * Kain meja dominan -> kotak meja -> HoughCircles -> klasifikasi warna (putih/8/solid/stripe).
 */
object TableAnalyzer {

    fun analyze(src: Bitmap, ignore: List<android.graphics.Rect> = emptyList()): Scene? {
        val rgba = Mat(); Utils.bitmapToMat(src, rgba)
        val bgr = Mat(); Imgproc.cvtColor(rgba, bgr, Imgproc.COLOR_RGBA2BGR)
        val hsv = Mat(); Imgproc.cvtColor(bgr, hsv, Imgproc.COLOR_BGR2HSV)
        val gray = Mat(); Imgproc.cvtColor(bgr, gray, Imgproc.COLOR_BGR2GRAY)

        val hue = dominantHue(hsv) ?: return null
        val mask = Mat()
        Core.inRange(
            hsv,
            Scalar(max(0.0, hue - 14.0), 60.0, 40.0),
            Scalar(min(179.0, hue + 14.0), 255.0, 255.0),
            mask
        )
        val k = Imgproc.getStructuringElement(Imgproc.MORPH_RECT, Size(9.0, 9.0))
        Imgproc.morphologyEx(mask, mask, Imgproc.MORPH_CLOSE, k)

        val contours = ArrayList<MatOfPoint>()
        Imgproc.findContours(mask.clone(), contours, Mat(), Imgproc.RETR_EXTERNAL, Imgproc.CHAIN_APPROX_SIMPLE)
        val biggest = contours.maxByOrNull { Imgproc.contourArea(it) } ?: return null
        val rect = Imgproc.boundingRect(biggest)
        if (rect.area() < 0.15 * src.width * src.height) return null

        val l = rect.x.toFloat(); val t = rect.y.toFloat()
        val r = (rect.x + rect.width).toFloat(); val b = (rect.y + rect.height).toFloat()
        val table = RectF(l, t, r, b)

        val pockets = mutableListOf(PointF(l, t), PointF(r, t), PointF(l, b), PointF(r, b))
        if (rect.width >= rect.height) {
            pockets += PointF((l + r) / 2, t); pockets += PointF((l + r) / 2, b)
        } else {
            pockets += PointF(l, (t + b) / 2); pockets += PointF(r, (t + b) / 2)
        }

        val roi = Mat(); Imgproc.GaussianBlur(gray.submat(rect), roi, Size(5.0, 5.0), 1.5)
        val len = max(rect.width, rect.height).toDouble()
        val minR = (len * 0.010).toInt().coerceAtLeast(4)
        val maxR = (len * 0.019).toInt().coerceAtLeast(minR + 2)
        val circles = Mat()
        Imgproc.HoughCircles(roi, circles, Imgproc.HOUGH_GRADIENT, 1.0, minR * 1.7, 110.0, 18.0, minR, maxR)

        data class C(val x: Float, val y: Float, val rad: Float)
        val found = ArrayList<C>()
        for (i in 0 until circles.cols()) {
            val c = circles.get(0, i) ?: continue
            found += C(c[0].toFloat() + rect.x, c[1].toFloat() + rect.y, c[2].toFloat())
        }
        if (found.isEmpty()) return null

        val ballR = found.map { it.rad }.sorted()[found.size / 2]
        val white = Mat()
        Core.inRange(hsv, Scalar(0.0, 0.0, 175.0), Scalar(179.0, 60.0, 255.0), white)

        var cue: Ball? = null
        var cueW = 0.7
        val others = ArrayList<Ball>()
        for (c in found) {
            if (pockets.any { hypot(c.x - it.x, c.y - it.y) < ballR * 2.2f }) continue
            if (ignore.any { it.contains(c.x.toInt(), c.y.toInt()) }) continue

            val rr = (c.rad * 0.8).toInt().coerceAtLeast(2)
            val x0 = (c.x - rr).toInt().coerceAtLeast(0); val y0 = (c.y - rr).toInt().coerceAtLeast(0)
            val x1 = min(hsv.cols(), (c.x + rr).toInt() + 1); val y1 = min(hsv.rows(), (c.y + rr).toInt() + 1)
            if (x1 - x0 < 3 || y1 - y0 < 3) continue
            val box = Rect(x0, y0, x1 - x0, y1 - y0)
            val m = Mat.zeros(box.size(), CvType.CV_8UC1)
            Imgproc.circle(m, Point(c.x - x0.toDouble(), c.y - y0.toDouble()), rr, Scalar(255.0), -1)

            val mean = Core.mean(hsv.submat(box), m)
            val mu = MatOfDouble(); val sd = MatOfDouble()
            Core.meanStdDev(gray.submat(box), mu, sd, m)
            val std = sd.get(0, 0)[0]
            val wm = Mat(); Core.bitwise_and(white.submat(box), m, wm)
            val total = Core.countNonZero(m).coerceAtLeast(1)
            val wf = Core.countNonZero(wm).toDouble() / total
            m.release(); wm.release()

            // cincin garis bidik game: bagian dalamnya masih kain polos -> bukan bola
            if (abs(mean.`val`[0] - hue) <= 10 && std < 10 && wf < 0.15) continue

            val pos = PointF(c.x, c.y)
            when {
                wf > cueW -> { cueW = wf; cue = Ball(pos, ballR, Kind.CUE) }
                mean.`val`[2] < 75 -> others += Ball(pos, ballR, Kind.EIGHT)
                else -> others += Ball(pos, ballR, Kind.OBJECT, stripe = wf > 0.22)
            }
        }
        return Scene(cue, others, pockets, table, ballR)
    }

    private fun dominantHue(hsv: Mat): Int? {
        val hist = IntArray(180)
        val x0 = hsv.cols() / 5; val x1 = hsv.cols() * 4 / 5
        val y0 = hsv.rows() / 5; val y1 = hsv.rows() * 4 / 5
        for (y in y0 until y1 step 6) for (x in x0 until x1 step 6) {
            val p = hsv.get(y, x) ?: continue
            if (p[1] > 70 && p[2] > 50) hist[p[0].toInt().coerceIn(0, 179)]++
        }
        val best = hist.indices.maxByOrNull { hist[it] } ?: return null
        return if (hist[best] > 50) best else null
    }
}
