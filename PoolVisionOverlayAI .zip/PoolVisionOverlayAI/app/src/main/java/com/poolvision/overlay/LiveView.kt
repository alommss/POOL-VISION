package com.poolvision.overlay

import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.roundToInt

/** Jendela overlay layar penuh, tembus sentuhan, menggambar garis bidik di atas game. */
class LiveView(ctx: Context) : View(ctx) {
    var scene: Scene? = null
    var plan: ShotPlan? = null

    private val neon = Color.parseColor("#00E5FF")
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = neon; style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val dash = Paint(line).apply { color = Color.parseColor("#AA00E5FF") }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = neon; setShadowLayer(6f, 0f, 0f, Color.BLACK) }
    private val loc = IntArray(2)

    override fun onDraw(c: Canvas) {
        val sc = scene ?: return
        val p = plan ?: return
        val cue = sc.cue ?: return
        getLocationOnScreen(loc)
        c.translate(-loc[0].toFloat(), -loc[1].toFloat())

        val r = sc.ballR
        line.strokeWidth = r * 0.22f
        dash.strokeWidth = r * 0.16f
        dash.pathEffect = DashPathEffect(floatArrayOf(r, r * 0.7f), 0f)
        ring.strokeWidth = r * 0.16f

        val mid = p.bounce
        if (mid != null) {
            c.drawLine(cue.pos.x, cue.pos.y, mid.x, mid.y, line)
            c.drawLine(mid.x, mid.y, p.ghost.x, p.ghost.y, line)
            ring.color = neon; c.drawCircle(mid.x, mid.y, r * 0.45f, ring)
        } else {
            c.drawLine(cue.pos.x, cue.pos.y, p.ghost.x, p.ghost.y, line)
        }
        ring.color = neon; c.drawCircle(p.ghost.x, p.ghost.y, r, ring)
        c.drawLine(p.target.pos.x, p.target.pos.y, p.pocket.x, p.pocket.y, dash)
        ring.color = Color.GREEN; c.drawCircle(p.target.pos.x, p.target.pos.y, r * 1.25f, ring)
        ring.color = Color.WHITE; c.drawCircle(p.pocket.x, p.pocket.y, r * 1.4f, ring)

        txt.textSize = r * 1.1f
        c.drawText("${p.aimDeg.roundToInt()}° • ${p.power}", cue.pos.x - r, cue.pos.y - r * 2f, txt)
    }
}
