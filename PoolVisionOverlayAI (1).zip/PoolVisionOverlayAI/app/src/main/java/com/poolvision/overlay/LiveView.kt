package com.poolvision.overlay

import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.roundToInt

/** Jendela overlay layar penuh, tembus sentuhan, menggambar prediksi jalur bola di atas game. */
class LiveView(ctx: Context) : View(ctx) {
    var scene: Scene? = null
    var plan: ShotPlan? = null
    var paths: List<TrajPath> = emptyList()

    private val neon = Color.parseColor("#00E5FF")
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.WHITE }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = neon; setShadowLayer(6f, 0f, 0f, Color.BLACK) }
    private val loc = IntArray(2)

    override fun onDraw(c: Canvas) {
        val sc = scene ?: return
        val cue = sc.cue ?: return
        getLocationOnScreen(loc)
        c.translate(-loc[0].toFloat(), -loc[1].toFloat())
        val r = sc.ballR
        line.strokeWidth = r * 0.2f
        ring.strokeWidth = r * 0.16f

        for (tp in paths) {
            val path = Path()
            tp.pts.forEachIndexed { i, q -> if (i == 0) path.moveTo(q.x, q.y) else path.lineTo(q.x, q.y) }
            line.color = tp.color
            c.drawPath(path, line)
            val end = tp.pts.last()
            dot.color = tp.color
            if (tp.pocketed) c.drawCircle(end.x, end.y, r * 1.2f, ring)
            else c.drawCircle(end.x, end.y, r * 0.35f, dot)
        }
        plan?.let {
            ring.color = Color.GREEN; c.drawCircle(it.target.pos.x, it.target.pos.y, r * 1.25f, ring)
            ring.color = Color.WHITE
            txt.textSize = r * 1.1f
            c.drawText("${it.aimDeg.roundToInt()}° • ${it.power}", cue.pos.x - r, cue.pos.y - r * 2f, txt)
        }
    }
}
