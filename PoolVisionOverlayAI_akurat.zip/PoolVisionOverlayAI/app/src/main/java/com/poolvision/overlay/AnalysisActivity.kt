package com.poolvision.overlay

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.TextView
import androidx.activity.ComponentActivity

class AnalysisActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val neon = Color.parseColor("#00E5FF")
        val view = AnalysisView(this).apply {
            bitmap = AnalysisStore.bitmap; scene = AnalysisStore.scene; plan = AnalysisStore.plan; paths = AnalysisStore.paths
        }
        val info = TextView(this).apply {
            setTextColor(neon); textSize = 14f; setPadding(32, 20, 32, 20)
            background = GradientDrawable().apply { cornerRadius = 32f; setColor(0xDD000000.toInt()); setStroke(2, neon) }
            text = view.plan?.describe() ?: "Tidak ada bidikan yang jelas. Coba ketuk bola target."
        }
        view.onPick = { ball ->
            val sc = AnalysisStore.scene
            if (sc != null) {
                val p = AimCalculator.plan(sc, ball)
                AnalysisStore.plan = p; view.plan = p
                val d = TrajectorySim.dirFromPlan(sc, p)
                val tp = if (d != null) TrajectorySim.simulate(sc, d) else emptyList()
                AnalysisStore.paths = tp; view.paths = tp
                info.text = p?.describe() ?: "Tidak ada jalur bebas ke bola itu."
                view.invalidate()
            }
        }
        val close = TextView(this).apply {
            text = "✕"; textSize = 22f; setTextColor(neon); setPadding(32, 16, 32, 16)
            setOnClickListener { finish() }
        }
        setContentView(FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            addView(view)
            addView(info, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = 24 })
            addView(close, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END))
        })
    }
}
