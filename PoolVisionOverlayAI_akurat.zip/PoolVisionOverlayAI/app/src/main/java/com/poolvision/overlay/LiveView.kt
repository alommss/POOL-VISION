package com.poolvision.overlay

import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.roundToInt

/** Jendela overlay layar penuh, tembus sentuhan, menggambar prediksi jalur bola di atas game. */
class LiveView(ctx: Context) : View(ctx) {
    var scene: Scene? = null
    var plan: ShotPlan? = null
    var paths: List<TrajPath> = emptyList()

    /**
     * true = jangan gambar ruas pertama bola putih (bola putih -> titik tumbukan).
     * Ruas itu sudah digambar garis bidik game; menimpanya membuat garis putih game tertutup
     * sehingga tidak terbaca lagi dan garis kita ikut telat/loncat.
     */
    var skipFirstLeg = false

    private val neon = Color.parseColor("#00E5FF")
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = neon; setShadowLayer(6f, 0f, 0f, Color.BLACK) }
    private val loc = IntArray(2)

    override fun onDraw(c: Canvas) {
        val sc = scene ?: return
        val cue = sc.cue ?: return
        getLocationOnScreen(loc)
        c.translate(-loc[0].toFloat(), -loc[1].toFloat())
        val r = sc.ballR
        line.strokeWidth = r * 0.2f
        ring.strokeWidth = r * 0.16f

        paths.forEachIndexed { idx, tp ->
            val from = if (idx == 0 && skipFirstLeg && tp.pts.size >= 2) 1 else 0
            val path = Path()
            for (i in from until tp.pts.size) {
                val q = tp.pts[i]
                if (i == from) path.moveTo(q.x, q.y) else path.lineTo(q.x, q.y)
            }
            line.color = tp.color
            c.drawPath(path, line)
            val end = tp.pts.last()
            dot.color = tp.color
            if (tp.pocketed) { ring.color = Color.GREEN; c.drawCircle(end.x, end.y, r * 1.2f, ring) }
            else {
                // titik berhenti: cincin berwarna jalur (bukan putih, agar tidak terbaca sebagai garis game)
                c.drawCircle(end.x, end.y, r * 0.35f, dot)
                ring.color = tp.color
                c.drawCircle(end.x, end.y, r * 0.95f, ring)
            }
        }
        plan?.let {
            ring.color = Color.GREEN; c.drawCircle(it.target.pos.x, it.target.pos.y, r * 1.25f, ring)
            txt.textSize = r * 1.1f
            c.drawText("${it.aimDeg.roundToInt()}° • ${it.power}", cue.pos.x - r, cue.pos.y - r * 2f, txt)
        }
    }
}
