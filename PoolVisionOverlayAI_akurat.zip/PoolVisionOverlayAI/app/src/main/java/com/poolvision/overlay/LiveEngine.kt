package com.poolvision.overlay

import android.graphics.PointF
import android.graphics.Rect
import android.os.SystemClock
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

/** Pengaturan dari panel; dibaca engine di setiap siklus. */
class LiveSettings {
    @Volatile var enabled = true
    @Volatile var group = Group.ALL
    @Volatile var useGameLine = true
    @Volatile var powerMode = 0          // 0 = AUTO (tarikan stik), 1..4 = 25/50/75/100%
}

/** Arah + tenaga -> jalur bola. Dipakai oleh engine live dan tombol ANALISIS. */
object PathBuilder {
    val POWERS = floatArrayOf(0.25f, 0.5f, 0.75f, 1f)

    /**
     * forceAuto = abaikan pengaturan panel (pakai arah stik + tarikan stik apa adanya),
     * dipakai untuk menilai pukulan nyata saat kalibrasi.
     */
    fun build(
        sc: Scene, plan: ShotPlan?, aim: PointF?, gapR: Float?,
        set: LiveSettings, calib: Calibration, forceAuto: Boolean = false
    ): List<TrajPath> {
        if (sc.cue == null) return emptyList()
        val dir = (if (set.useGameLine || forceAuto) aim else null)
            ?: TrajectorySim.dirFromPlan(sc, plan) ?: return emptyList()
        val distR = when {
            !forceAuto && set.powerMode != 0 -> calib.distForPower(POWERS[set.powerMode - 1])
            gapR != null -> calib.distR(gapR)
            else -> calib.distForPower(0.7f)
        }
        val energy = (distR * sc.ballR).coerceAtLeast(sc.ballR)
        return TrajectorySim.simulate(sc, dir, energy)
    }
}

/**
 * Mesin live: satu thread yang terus-menerus
 *  SCAN : analisis penuh meja (garis disembunyikan sebentar)  ->
 *  AIM  : baca arah stik + tarikan stik ±20-30x/detik, gambar prediksi  ->
 *  MOVE : bola putih terlepas -> prediksi DITAHAN, tunggu semua bola berhenti -> SCAN lagi.
 * Setelah pukulan "bersih" posisi berhenti bola putih yang nyata dipakai untuk melatih Calibration.
 */
class LiveEngine(
    private val capture: ScreenCapture,
    private val calib: Calibration,
    private val set: LiveSettings,
    private val ui: Ui
) {
    interface Ui {
        fun setLineVisible(visible: Boolean)          // boleh dipanggil dari thread mana pun, menunggu selesai
        fun draw(scene: Scene?, plan: ShotPlan?, paths: List<TrajPath>, skipFirstLeg: Boolean)
        fun status(text: String)
        fun ignoreRects(): List<Rect>
    }

    private enum class St { SCAN, AIM, MOVE }

    private class Sample(val t: Long, val gap: Float, val dir: PointF?)

    private class Shot(
        val start: PointF, val dir: PointF, val gapR: Float,
        val clean: Boolean, val predR: Float, val balls: List<PointF>
    )

    @Volatile private var running = false
    @Volatile private var replanRequested = false
    private var thread: Thread? = null

    private var st = St.SCAN
    private var scene: Scene? = null
    private var plan: ShotPlan? = null
    private var nextScanAt = 0L
    private var lastScanAt = 0L
    private var wasDisabled = false

    // pembacaan stik
    private var aim: PointF? = null
    private var aimAt = 0L
    private var gapR: Float? = null
    private var gapAt = 0L
    private val recent = ArrayList<Sample>()

    // prediksi yang ditahan saat stik dilepas
    private var frozen: List<TrajPath>? = null
    private var frozenAt = 0L
    private var frozenGap = 0f
    private var frozenDir: PointF? = null

    // pukulan yang sedang berlangsung
    private var shot: Shot? = null
    private var moveAt = 0L
    private var still = 0

    private var lastSay = ""

    fun start() {
        if (running) return
        running = true
        thread = Thread({ loop() }, "pv-engine").also { it.isDaemon = true; it.start() }
    }

    fun stop() {
        running = false
        thread?.interrupt()
        thread = null
        TableAnalyzer.resetMotion()
    }

    fun replan() { replanRequested = true }

    private fun say(t: String) { if (t != lastSay) { lastSay = t; ui.status(t) } }

    private fun loop() {
        TableAnalyzer.resetMotion()
        while (running) {
            val t0 = SystemClock.uptimeMillis()
            try {
                if (!set.enabled) {
                    if (!wasDisabled) { wasDisabled = true; ui.draw(null, null, emptyList(), false) }
                    Thread.sleep(200)
                    continue
                }
                if (wasDisabled) { wasDisabled = false; st = St.SCAN; nextScanAt = 0L }
                when (st) {
                    St.SCAN -> scanStep()
                    St.AIM -> aimStep()
                    St.MOVE -> moveStep()
                }
            } catch (e: InterruptedException) {
                break
            } catch (e: Throwable) {
                say("Kesalahan: ${e.javaClass.simpleName}")
                try { Thread.sleep(300) } catch (_: InterruptedException) { break }
            }
            val dt = SystemClock.uptimeMillis() - t0
            if (dt < 12) try { Thread.sleep(12 - dt) } catch (_: InterruptedException) { break }
        }
    }

    // ------------------------------------------------------------------ SCAN

    private fun scanStep() {
        val now = SystemClock.uptimeMillis()
        if (now < nextScanAt) { Thread.sleep(40); return }
        ui.setLineVisible(false)                       // agar garis kita tidak ikut terbaca
        Thread.sleep(140)
        val bmp = capture.grab()
        ui.setLineVisible(true)
        if (bmp == null) { say("Gagal ambil layar."); nextScanAt = SystemClock.uptimeMillis() + 600; return }

        val sc = try { TableAnalyzer.analyze(bmp, ui.ignoreRects()) } catch (e: Throwable) { null }
        lastScanAt = SystemClock.uptimeMillis()
        if (sc == null) {
            scene = null; plan = null; resetAim()
            ui.draw(null, null, emptyList(), false)
            say("Meja tidak terdeteksi.")
            nextScanAt = lastScanAt + 900
            return
        }
        val note = resolveShot(sc)
        scene = sc
        plan = AimCalculator.plan(sc, null, set.group)
        resetAim()
        if (sc.cue == null) {
            ui.draw(sc, plan, emptyList(), false)
            say("Bola putih tidak terlihat.")
            nextScanAt = lastScanAt + 800
            return
        }
        TableAnalyzer.resetMotion()
        st = St.AIM
        say(listOfNotNull(note, plan?.describe() ?: "Tidak ada bidikan jelas.").joinToString("\n"))
    }

    private fun resetAim() {
        aim = null; gapR = null; recent.clear(); frozen = null
    }

    // ------------------------------------------------------------------ AIM

    private fun smoothDir(prev: PointF?, raw: PointF): PointF {
        if (prev == null) return raw
        val a0 = atan2(prev.y.toDouble(), prev.x.toDouble())
        val a1 = atan2(raw.y.toDouble(), raw.x.toDouble())
        var d = a1 - a0
        while (d > Math.PI) d -= 2 * Math.PI
        while (d < -Math.PI) d += 2 * Math.PI
        val k = if (abs(d) > Math.toRadians(1.5)) 1.0 else 0.55   // gerakan besar: langsung ikut
        val a = a0 + d * k
        return PointF(cos(a).toFloat(), sin(a).toFloat())
    }

    private fun aimStep() {
        val sc = scene
        val cue = sc?.cue
        if (sc == null || cue == null) { st = St.SCAN; return }
        if (replanRequested) { replanRequested = false; plan = AimCalculator.plan(sc, null, set.group) }

        val bmp = capture.grabShared()
        if (bmp == null) { Thread.sleep(30); return }
        val now = SystemClock.uptimeMillis()
        val q = TableAnalyzer.quick(bmp, sc, aim)
        if (q == null) { Thread.sleep(30); return }

        // 1) bola putih sudah tidak di tempatnya -> pukulan dilepas (atau bola dipindah)
        if (q.cuePresence < 0.40f) { onCueMoved(sc, now); return }

        // 2) prediksi sedang ditahan karena stik baru dilepas
        if (frozen != null) {
            if (now - frozenAt > 700L) { frozen = null; gapR = null; recent.clear() } else return
        }

        // 3) arah stik
        val rawAim = q.aimDir
        if (rawAim != null) { aim = smoothDir(aim, rawAim); aimAt = now }

        // 4) tarikan stik (+ deteksi "lunge": stik melesat ke bola)
        val rawGap = q.gapR
        if (rawGap != null) {
            val g = gapR
            val dtS = (now - gapAt).coerceAtLeast(1L) / 1000f
            if (g != null && g > 1.2f && recent.isNotEmpty() && (g - rawGap) / dtS > 45f) {
                freeze(sc, now)
                return
            }
            val smoothed = if (g == null || now - gapAt > 600L) rawGap else g + (rawGap - g) * 0.6f
            gapR = smoothed; gapAt = now
            recent += Sample(now, smoothed, aim)
            while (recent.isNotEmpty() && now - recent[0].t > 300L) recent.removeAt(0)
        }

        // 5) safety: kalau tidak ada garis bidik lama, segarkan analisis sesekali
        if ((aim == null || now - aimAt > 1500L) && now - lastScanAt > 15000L) { st = St.SCAN; nextScanAt = 0L; return }

        // 6) gambar
        val dirNow = if (aim != null && now - aimAt <= 600L) aim else null
        val gapNow = if (gapR != null && now - gapAt <= 600L) gapR else null
        val paths = PathBuilder.build(sc, plan, dirNow, gapNow, set, calib)
        ui.draw(sc, plan, paths, set.useGameLine && dirNow != null)
    }

    /** Stik melesat: kunci prediksi dari tarikan puncak 300 ms terakhir (bukan nilai saat stik sudah maju). */
    private fun freeze(sc: Scene, now: Long) {
        val pk = recent.maxByOrNull { it.gap } ?: return
        val dir = pk.dir ?: aim
        frozenGap = pk.gap; frozenDir = dir; frozenAt = now
        val p = PathBuilder.build(sc, plan, dir, pk.gap, set, calib)
        frozen = p
        ui.draw(sc, plan, p, set.useGameLine && dir != null)
    }

    private fun onCueMoved(sc: Scene, now: Long) {
        val cue = sc.cue
        val fr = frozen
        val pk = recent.maxByOrNull { it.gap }
        val gap: Float? = if (fr != null) frozenGap else pk?.gap
        val dir: PointF? = (if (fr != null) frozenDir else pk?.dir) ?: aim
        shot = null
        if (cue != null && gap != null && gap >= 1.0f && dir != null) {
            val r = sc.ballR
            // pukulan "bersih"? (bola putih berhenti sendiri tanpa kena bola/bantalan menurut simulasi)
            val auto = PathBuilder.build(sc, plan, dir, gap, set, calib, forceAuto = true)
            val cp = auto.firstOrNull()
            val clean = cp != null && cp.pts.size == 2 && !cp.pocketed
            val predR = if (cp != null && cp.pts.size >= 2)
                hypot(cp.pts[1].x - cp.pts[0].x, cp.pts[1].y - cp.pts[0].y) / r else 0f
            shot = Shot(PointF(cue.pos.x, cue.pos.y), dir, gap, clean, predR, sc.balls.map { PointF(it.pos.x, it.pos.y) })
            val shown = fr ?: PathBuilder.build(sc, plan, dir, gap, set, calib)
            ui.draw(sc, plan, shown, set.useGameLine)
        }
        frozen = null; recent.clear(); gapR = null
        st = St.MOVE; moveAt = now; still = 0
        TableAnalyzer.resetMotion()
        say("Bola bergerak… prediksi ditahan.")
    }

    // ------------------------------------------------------------------ MOVE

    private fun moveStep() {
        val sc = scene
        if (sc == null) { st = St.SCAN; return }
        val bmp = capture.grabShared()
        if (bmp == null) { Thread.sleep(40); return }
        val m = TableAnalyzer.motion(bmp, sc)
        if (m != null) { if (m < 0.0006f) still++ else still = 0 }
        Thread.sleep(40)
        val elapsed = SystemClock.uptimeMillis() - moveAt
        if ((still >= 6 && elapsed >= 700L) || elapsed > 9000L) {
            TableAnalyzer.resetMotion()
            st = St.SCAN; nextScanAt = 0L
        }
    }

    // ------------------------------------------------------------------ kalibrasi

    /** Bandingkan tempat berhenti bola putih yang NYATA dengan prediksi; latih model jika pukulannya bersih. */
    private fun resolveShot(nw: Scene): String? {
        val s = shot ?: return null
        shot = null
        val cue = nw.cue ?: return null
        val r = nw.ballR
        val dx = cue.pos.x - s.start.x; val dy = cue.pos.y - s.start.y
        val len = hypot(dx, dy)
        if (len < r * 1.5f) return null
        if (!s.clean) return null
        val dot = (dx * s.dir.x + dy * s.dir.y) / len
        if (dot < 0.99f) return null                                   // melenceng/membelok: bukan pukulan lurus bersih
        if (nw.balls.size != s.balls.size) return null
        for (b in s.balls) {                                           // bola lain tidak boleh bergeser
            if (nw.balls.none { hypot(it.pos.x - b.x, it.pos.y - b.y) < r * 0.7f }) return null
        }
        val tb = nw.table; val mg = r * 1.3f
        if (cue.pos.x < tb.left + mg || cue.pos.x > tb.right - mg ||
            cue.pos.y < tb.top + mg || cue.pos.y > tb.bottom - mg) return null   // berhenti di bantalan: tidak pasti
        return calib.addSample(s.gapR, len / r, s.predR)
    }
}
