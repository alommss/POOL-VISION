package com.poolvision.overlay

import android.content.Context
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.roundToInt

/**
 * Model jarak tempuh bola putih dari tarikan stik, dalam satuan jari-jari bola (r):
 *     jarak = a * (gap - G0)^b
 * Awalnya memakai nilai tebakan. Setiap pukulan "bersih" (bola putih tidak kena bola/bantalan)
 * dipakai untuk belajar a dan b dari hasil NYATA, lalu disimpan permanen di HP.
 */
class Calibration(ctx: Context) {
    companion object {
        const val G0 = 0.6f          // tarikan mati (satuan r)
        const val GAP_FULL = 9.7f    // perkiraan tarikan penuh (satuan r), untuk mode tenaga manual
        const val A_PRIOR = 3.3f
        const val B_PRIOR = 2f
        private const val MAX_SAMPLES = 24
    }

    private val prefs = ctx.getSharedPreferences("pv_calib", Context.MODE_PRIVATE)
    private val xs = ArrayList<Float>()      // gap - G0
    private val ys = ArrayList<Float>()      // jarak nyata (r)

    @Volatile var a = A_PRIOR
        private set
    @Volatile var b = B_PRIOR
        private set

    init {
        a = prefs.getFloat("a", A_PRIOR)
        b = prefs.getFloat("b", B_PRIOR)
        prefs.getString("s", "")?.split(";")?.forEach {
            val p = it.split(":")
            if (p.size == 2) {
                val x = p[0].toFloatOrNull(); val y = p[1].toFloatOrNull()
                if (x != null && y != null && x > 0f && y > 0f) { xs += x; ys += y }
            }
        }
    }

    /** Jarak tempuh (satuan r) untuk tarikan stik gapR (satuan r). */
    fun distR(gapR: Float): Float = a * max(gapR - G0, 0.15f).pow(b)

    /** Jarak tempuh untuk tenaga manual 0..1 (1 = tarikan penuh). */
    fun distForPower(p: Float): Float = distR(G0 + p.coerceIn(0.05f, 1f) * (GAP_FULL - G0))

    fun percent(): Int = (a / A_PRIOR * 100f).roundToInt()

    @Synchronized fun samples(): Int = xs.size

    /** Catat hasil satu pukulan bersih. Mengembalikan teks status. */
    @Synchronized
    fun addSample(gapR: Float, actualR: Float, predictedR: Float): String {
        val x = gapR - G0
        if (x < 0.4f || actualR < 1f) return "Kalibrasi: pukulan terlalu pelan, diabaikan."
        if (xs.size >= 3) {
            val ratio = actualR / (a * x.pow(b))
            if (ratio > 2.5f || ratio < 0.4f)
                return "Kalibrasi: hasil janggal (aktual ${actualR.roundToInt()} r vs prediksi ${predictedR.roundToInt()} r), diabaikan."
        }
        xs += x; ys += actualR
        while (xs.size > MAX_SAMPLES) { xs.removeAt(0); ys.removeAt(0) }
        refit(); save()
        return "Kalibrasi: prediksi ${predictedR.roundToInt()} r, aktual ${actualR.roundToInt()} r • ${xs.size} sampel"
    }

    /** Tombol JARAK −/+ : geser seluruh model sekaligus dengan sampelnya. */
    @Synchronized
    fun nudge(f: Float) {
        a = (a * f).coerceIn(0.3f, 25f)
        for (i in ys.indices) ys[i] = ys[i] * f
        save()
    }

    @Synchronized
    fun reset() { xs.clear(); ys.clear(); a = A_PRIOR; b = B_PRIOR; save() }

    private fun refit() {
        val n = xs.size
        if (n == 0) return
        val lx = DoubleArray(n) { ln(xs[it].toDouble()) }
        val ly = DoubleArray(n) { ln(ys[it].toDouble()) }
        val spread = (xs.maxOrNull() ?: 1f) / (xs.minOrNull() ?: 1f)
        if (n >= 4 && spread >= 1.5f) {
            // regresi log-log dengan "tarikan" lembut ke b = 2 (fisika: jarak ~ kecepatan^2)
            val mx = lx.average(); val my = ly.average()
            var sxx = 0.0; var sxy = 0.0
            for (i in 0 until n) {
                sxx += (lx[i] - mx) * (lx[i] - mx)
                sxy += (lx[i] - mx) * (ly[i] - my)
            }
            val lam = 0.8
            val bb = ((sxy + lam * B_PRIOR) / (sxx + lam)).coerceIn(1.3, 2.6)
            b = bb.toFloat()
            a = exp(my - bb * mx).toFloat()
        } else {
            // sampel sedikit / rentang sempit: b tetap 2, a = median, dicampur dengan tebakan awal
            val lnA = DoubleArray(n) { ly[it] - B_PRIOR * lx[it] }.sortedArray()
            val med = lnA[n / 2]
            val w = n / (n + 1.5)
            b = B_PRIOR
            a = exp((1 - w) * ln(A_PRIOR.toDouble()) + w * med).toFloat()
        }
        a = a.coerceIn(0.3f, 25f)
    }

    private fun save() {
        val s = xs.indices.joinToString(";") { "${xs[it]}:${ys[it]}" }
        prefs.edit().putFloat("a", a).putFloat("b", b).putString("s", s).apply()
    }
}
