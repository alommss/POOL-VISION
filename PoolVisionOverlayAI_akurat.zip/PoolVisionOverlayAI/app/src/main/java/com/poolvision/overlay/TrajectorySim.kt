package com.poolvision.overlay

import android.graphics.PointF
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

data class TrajPath(val pts: List<PointF>, val color: Int, val pocketed: Boolean)

/**
 * Simulasi 2D sederhana tanpa spin: tabrakan bola sama massa (elastis), pantulan bantalan
 * dengan kehilangan energi, jarak tempuh ~ energi (gesekan konstan). Bola lain dianggap diam.
 */
object TrajectorySim {
    private val COLORS = intArrayOf(
        0xFF00E5FF.toInt(), 0xFFFF3B3B.toInt(), 0xFFB050FF.toInt(), 0xFFFFA726.toInt(), 0xFFFFEB3B.toInt()
    )

    fun unit(x: Float, y: Float): PointF { val l = hypot(x, y).coerceAtLeast(1e-4f); return PointF(x / l, y / l) }

    fun dirFromPlan(scene: Scene, plan: ShotPlan?): PointF? {
        val c = scene.cue ?: return null
        val f = plan?.let { it.bounce ?: it.ghost } ?: return null
        return unit(f.x - c.pos.x, f.y - c.pos.y)
    }

    private class Mover(val start: PointF, val dir: PointF, val energy: Float, val colorIdx: Int)

    private fun rayCircle(p: PointF, d: PointF, c: PointF, rad: Float): Float? {
        val fx = p.x - c.x; val fy = p.y - c.y
        val b = fx * d.x + fy * d.y
        val cc = fx * fx + fy * fy - rad * rad
        val disc = b * b - cc
        if (disc < 0f) return null
        val t = -b - sqrt(disc)
        return if (t > 1e-3f) t else null
    }

    fun simulate(scene: Scene, dir: PointF, energy: Float? = null): List<TrajPath> {
        val cue = scene.cue ?: return emptyList()
        val r = scene.ballR
        val tb = scene.table
        val tableLen = max(tb.width(), tb.height())
        val moved = ArrayList<Ball>()
        val result = ArrayList<TrajPath>()
        val queue = ArrayDeque<Mover>()
        queue.add(Mover(cue.pos, dir, (energy ?: (tableLen * 2.5f)).coerceAtLeast(r), 0))
        var nextColor = 1
        var guard = 0

        while (queue.isNotEmpty() && guard++ < 6) {
            val m = queue.removeFirst()
            var p = PointF(m.start.x, m.start.y)
            var d = m.dir
            var e = m.energy
            val pts = arrayListOf(PointF(p.x, p.y))
            var events = 0
            var pocketed = false

            while (e > r * 0.5f && events < 4) {
                var tBest = e
                var kind = 0            // 0 berhenti, 1 bola, 2 bantalan, 3 lubang
                var hit: Ball? = null
                var axisX = false
                var pocket: PointF? = null

                for (b in scene.balls) {
                    if (moved.any { it === b }) continue
                    val t = rayCircle(p, d, b.pos, 2 * r)
                    if (t != null && t < tBest) { tBest = t; kind = 1; hit = b }
                }
                // bantalan (batas pusat bola)
                val tx = when {
                    d.x > 1e-4f -> (tb.right - r - p.x) / d.x
                    d.x < -1e-4f -> (tb.left + r - p.x) / d.x
                    else -> Float.MAX_VALUE
                }
                val ty = when {
                    d.y > 1e-4f -> (tb.bottom - r - p.y) / d.y
                    d.y < -1e-4f -> (tb.top + r - p.y) / d.y
                    else -> Float.MAX_VALUE
                }
                val tc = min(tx, ty)
                if (tc > 1e-3f && tc < tBest) { tBest = tc; kind = 2; axisX = tx < ty }
                // lubang
                val pr = r * 1.7f
                for (pk in scene.pockets) {
                    val s = (pk.x - p.x) * d.x + (pk.y - p.y) * d.y
                    val perp = kotlin.math.abs((pk.x - p.x) * d.y - (pk.y - p.y) * d.x)
                    if (s > 0f && perp < pr) {
                        val tp = (s - sqrt(pr * pr - perp * perp)).coerceAtLeast(0f)
                        if (tp < tBest) { tBest = tp; kind = 3; pocket = pk }
                    }
                }

                when (kind) {
                    0 -> { p = PointF(p.x + d.x * e, p.y + d.y * e); pts += PointF(p.x, p.y); e = 0f }
                    1 -> {
                        val b = hit!!
                        p = PointF(p.x + d.x * tBest, p.y + d.y * tBest); pts += PointF(p.x, p.y)
                        val n = unit(b.pos.x - p.x, b.pos.y - p.y)
                        val c = (d.x * n.x + d.y * n.y).coerceIn(0f, 1f)
                        val rem = e - tBest
                        moved += b
                        val objE = rem * c * c
                        if (objE > r && queue.size < 5) queue.add(Mover(b.pos, n, objE, min(nextColor++, 4)))
                        d = unit(d.x - c * n.x, d.y - c * n.y)
                        e = rem * (1f - c * c)
                        events++
                    }
                    2 -> {
                        p = PointF(p.x + d.x * tBest, p.y + d.y * tBest); pts += PointF(p.x, p.y)
                        d = if (axisX) PointF(-d.x, d.y) else PointF(d.x, -d.y)
                        e = (e - tBest) * 0.72f
                        events++
                    }
                    else -> {
                        pts += PointF(pocket!!.x, pocket.y); pocketed = true; e = 0f
                    }
                }
                if (pocketed) break
            }
            result += TrajPath(pts, COLORS[min(m.colorIdx, 4)], pocketed)
        }
        return result
    }
}
