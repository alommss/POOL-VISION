package com.poolvision.overlay

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.*
import org.opencv.android.OpenCVLoader
import java.util.concurrent.Executors

class OverlayService : Service() {

    companion object {
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        const val ACTION_STOP = "stop"
        private const val CH = "pv_overlay"
        val NEON = Color.parseColor("#00E5FF")
    }

    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams
    private var root: FrameLayout? = null
    private lateinit var panel: LinearLayout
    private lateinit var bubble: TextView
    private lateinit var status: TextView
    private lateinit var analyzeBtn: Button

    private var projection: MediaProjection? = null
    private var capture: ScreenCapture? = null
    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private var enabled = true
    private var expanded = false

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        if (root != null) return START_NOT_STICKY

        startAsForeground()
        val code = intent?.getIntExtra(EXTRA_CODE, 0) ?: 0
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33)
            intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        else @Suppress("DEPRECATION") intent?.getParcelableExtra(EXTRA_DATA)
        if (data == null) { stopSelf(); return START_NOT_STICKY }

        OpenCVLoader.initLocal()
        val mpm = getSystemService(MediaProjectionManager::class.java)
        projection = mpm.getMediaProjection(code, data).also {
            it.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { main.post { stopSelf() } }
            }, main)
        }
        capture = ScreenCapture(this, projection!!)
        buildOverlay()
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Pool Vision", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 0, Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CH)
            .setContentTitle("Pool Vision Overlay AI aktif")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .addAction(Notification.Action.Builder(null, "Berhenti", stop).build())
            .setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildOverlay() {
        wm = getSystemService(WindowManager::class.java)
        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(8); y = dp(160) }

        bubble = TextView(this).apply {
            text = "◎"; gravity = Gravity.CENTER; setTextColor(NEON); textSize = 24f
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL; setColor(0xCC000000.toInt()); setStroke(dp(2), NEON)
            }
            layoutParams = FrameLayout.LayoutParams(dp(52), dp(52))
            alpha = 0.7f
        }

        status = TextView(this).apply {
            text = "Siap. Buka meja lalu tekan ANALISIS."
            setTextColor(0xFF9FE9F5.toInt()); textSize = 11f
        }
        val sw = Switch(this).apply {
            text = "AI ON  "; setTextColor(Color.WHITE); isChecked = true
            setOnCheckedChangeListener { _, on -> setEnabledState(on) }
        }
        analyzeBtn = Button(this).apply {
            text = "ANALISIS"; setTextColor(Color.BLACK)
            background = GradientDrawable().apply { cornerRadius = dp(10).toFloat(); setColor(NEON) }
            setOnClickListener { analyze() }
        }
        val minBtn = smallBtn("Minimalkan") { togglePanel(false) }
        val closeBtn = smallBtn("Tutup") { stopSelf() }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(minBtn, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(closeBtn, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }

        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(10), dp(12), dp(8))
            background = GradientDrawable().apply {
                cornerRadius = dp(16).toFloat(); setColor(0xE6000000.toInt()); setStroke(dp(1), NEON)
            }
            addView(TextView(context).apply { text = "POOL VISION"; setTextColor(NEON); textSize = 13f })
            addView(sw); addView(analyzeBtn); addView(status); addView(row)
            visibility = View.GONE
            layoutParams = FrameLayout.LayoutParams(dp(210), FrameLayout.LayoutParams.WRAP_CONTENT)
                .apply { topMargin = dp(58) }
        }

        root = FrameLayout(this).apply { addView(bubble); addView(panel) }
        attachDrag()
        wm.addView(root, lp)
    }

    private fun smallBtn(t: String, f: () -> Unit) = Button(this).apply {
        text = t; textSize = 11f; setTextColor(NEON); background = null; isAllCaps = false
        setOnClickListener { f() }
    }

    private fun attachDrag() {
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        bubble.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx; val dy = e.rawY - sy
                    if (moved || Math.abs(dx) > slop || Math.abs(dy) > slop) {
                        moved = true; lp.x = ox + dx.toInt(); lp.y = oy + dy.toInt()
                        wm.updateViewLayout(root, lp)
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved) togglePanel(!expanded)
            }
            true
        }
    }

    private fun togglePanel(show: Boolean) {
        expanded = show
        if (show) {
            panel.alpha = 0f; panel.scaleX = 0.9f; panel.scaleY = 0.9f; panel.visibility = View.VISIBLE
            panel.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(180).start()
            bubble.animate().alpha(1f).setDuration(180).start()
        } else {
            panel.animate().alpha(0f).scaleX(0.9f).scaleY(0.9f).setDuration(150)
                .withEndAction { panel.visibility = View.GONE }.start()
            bubble.animate().alpha(if (enabled) 0.7f else 0.3f).setDuration(150).start()
        }
    }

    private fun setEnabledState(on: Boolean) {
        enabled = on
        analyzeBtn.isEnabled = on; analyzeBtn.alpha = if (on) 1f else 0.4f
        bubble.animate().alpha(if (on) 1f else 0.3f).setDuration(150).start()
        status.text = if (on) "AI aktif." else "AI nonaktif."
    }

    private fun analyze() {
        val r = root ?: return
        if (!enabled) return
        status.text = "Menganalisis…"
        r.visibility = View.INVISIBLE            // sembunyikan overlay agar tidak ikut tertangkap
        main.postDelayed({
            worker.execute {
                val bmp = capture?.grab()
                main.post { r.visibility = View.VISIBLE }
                if (bmp == null) { main.post { status.text = "Gagal ambil layar, coba lagi." }; return@execute }
                val scene = try { TableAnalyzer.analyze(bmp) } catch (e: Throwable) { null }
                val plan = scene?.let { AimCalculator.plan(it) }
                main.post {
                    if (scene == null) {
                        status.text = "Meja tidak terdeteksi. Pastikan game di layar."
                    } else {
                        AnalysisStore.bitmap = bmp; AnalysisStore.scene = scene; AnalysisStore.plan = plan
                        status.text = plan?.describe() ?: "Tidak ada bidikan yang jelas."
                        startActivity(Intent(this, AnalysisActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    }
                }
            }
        }, 250)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        try { capture?.resize() } catch (_: Exception) {}
    }

    override fun onDestroy() {
        root?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        root = null
        capture?.release(); capture = null
        projection?.stop(); projection = null
        worker.shutdownNow()
        super.onDestroy()
    }
}
