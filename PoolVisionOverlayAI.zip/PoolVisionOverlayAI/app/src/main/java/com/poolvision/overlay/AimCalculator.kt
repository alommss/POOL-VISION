package com.poolvision.overlay

import android.graphics.PointF
import android.graphics.RectF
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.atan2
import kotlin.math.hypot

/** Geometri "ghost ball": estimasi sudut, cek jalur bebas, dan pantulan satu bantalan. */
object AimCalculator {

    private fun sub(a: PointF, b: PointF) = PointF(a.x - b.x, a.y - b.y)
    private fun len(a: PointF) = hypot(a.x, a.y)
    private fun unit(a: PointF): PointF { val l = len(a).coerceAtLeast(1e-3f); return PointF(a.x / l, a.y / l) }
    private fun dist(a: PointF, b: PointF) = hypot(a.x - b.x, a.y - b.y)

    private fun segDist(p: PointF, a: PointF, b: PointF): Float {
        val ab = sub(b, a); val ap = sub(p, a)
        val t = ((ap.x * ab.x + ap.y * ab.y) / (ab.x * ab.x + ab.y * ab.y + 1e-6f)).coerceIn(0f, 1f)
        return hypot(p.x - (a.x + t * ab.x), p.y - (a.y + t * ab.y))
    }

    private fun clear(a: PointF, b: PointF, others: List<Ball>, minDist: Float) =
        others.none { segDist(it.pos, a, b) < minDist }

    private fun angle(u: PointF, v: PointF): Float =
        Math.toDegrees(acos((u.x * v.x + u.y * v.y).coerceIn(-1f, 1f).toDouble())).toFloat()

    private fun inside(p: PointF, tb: RectF, m: Float) =
        p.x in (tb.left + m)..(tb.right - m) && p.y in (tb.top + m)..(tb.bottom - m)

    /** Titik pantulan: cermin ghost ball terhadap tiap bantalan, tarik garis dari bola putih. */
    private fun bankPoints(cue: PointF, ghost: PointF, tb: RectF, r: Float): List<PointF> {
        val out = ArrayList<PointF>()
        for (c in listOf(tb.left + r, tb.right - r)) {
            val gm = PointF(2 * c - ghost.x, ghost.y)
            val dx = gm.x - cue.x
            if (abs(dx) < 1e-3f) continue
            val s = (c - cue.x) / dx
            if (s <= 0f || s >= 1f) continue
            val b = PointF(c, cue.y + s * (gm.y - cue.y))
            if (b.y in (tb.top + r)..(tb.bottom - r)) out += b
        }
        for (c in listOf(tb.top + r, tb.bottom - r)) {
            val gm = PointF(ghost.x, 2 * c - ghost.y)
            val dy = gm.y - cue.y
            if (abs(dy) < 1e-3f) continue
            val s = (c - cue.y) / dy
            if (s <= 0f || s >= 1f) continue
            val b = PointF(cue.x + s * (gm.x - cue.x), c)
            if (b.x in (tb.left + r)..(tb.right - r)) out += b
        }
        return out
    }

    fun plan(scene: Scene, forced: Ball? = null): ShotPlan? {
        val cue = scene.cue ?: return null
        val r = scene.ballR
        val tb = scene.table
        val tableLen = maxOf(tb.width(), tb.height())
        val targets = if (forced != null) listOf(forced) else scene.balls

        var best: ShotPlan? = null
        var bestCost = Float.MAX_VALUE

        for (t in targets) {
            val others = scene.balls.filter { it !== t }
            for (pk in scene.pockets) {
                val dir = unit(sub(pk, t.pos))
                val ghost = PointF(t.pos.x - dir.x * 2 * r, t.pos.y - dir.y * 2 * r)
                if (!inside(ghost, tb, r * 0.5f)) continue
                if (!clear(t.pos, pk, others, r * 1.9f)) continue

                // 1) jalur lurus
                if (clear(cue.pos, ghost, others, r * 2f)) {
                    val cut = angle(unit(sub(ghost, cue.pos)), dir)
                    if (cut <= 78f) {
                        val total = dist(cue.pos, ghost) + dist(t.pos, pk)
                        val cost = cut + 30f * total / tableLen
                        if (cost < bestCost) {
                            bestCost = cost
                            best = make(t, pk, ghost, null, cue.pos, cut, ShotType.STRAIGHT, total, tableLen)
                        }
                    }
                    continue
                }
                // 2) pantulan satu bantalan
                for (b in bankPoints(cue.pos, ghost, tb, r)) {
                    if (!clear(cue.pos, b, others, r * 2f) || !clear(b, ghost, others, r * 2f)) continue
                    val cut = angle(unit(sub(ghost, b)), dir)
                    if (cut > 70f) continue
                    val total = dist(cue.pos, b) + dist(b, ghost) + dist(t.pos, pk)
                    val cost = cut + 30f * total / tableLen + 25f
                    if (cost < bestCost) {
                        bestCost = cost
                        best = make(t, pk, ghost, b, cue.pos, cut, ShotType.BANK, total, tableLen)
                    }
                }
            }
        }
        return best
    }

    private fun make(
        t: Ball, pk: PointF, ghost: PointF, bounce: PointF?, cue: PointF,
        cut: Float, type: ShotType, total: Float, tableLen: Float
    ): ShotPlan {
        val first = bounce ?: ghost
        val aim = Math.toDegrees(atan2((first.y - cue.y).toDouble(), (first.x - cue.x).toDouble())).toFloat()
        val frac = total / tableLen
        val power = when { frac < 0.35f -> "pelan"; frac < 0.75f -> "sedang"; else -> "kuat" }
        return ShotPlan(t, pk, ghost, bounce, cut, (aim + 360f) % 360f, type, power)
    }
}
