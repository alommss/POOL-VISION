package com.poolvision.overlay

import android.content.Context
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.util.DisplayMetrics
import android.view.WindowManager

/** Menyimpan frame terbaru dari MediaProjection; frame diambil hanya saat pengguna menekan Analisis. */
class ScreenCapture(private val ctx: Context, projection: MediaProjection) {
    private val handler = Handler(HandlerThread("pv-capture").also { it.start() }.looper)
    private val lock = Any()
    private var last: Image? = null
    private var reader: ImageReader
    private val display: VirtualDisplay
    private val dpi = ctx.resources.configuration.densityDpi

    init {
        val (w, h) = screenSize()
        reader = newReader(w, h)
        display = projection.createVirtualDisplay(
            "PoolVision", w, h, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.surface, null, handler
        )
    }

    private fun screenSize(): Pair<Int, Int> {
        val wm = ctx.getSystemService(WindowManager::class.java)
        return if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.maximumWindowMetrics.bounds; b.width() to b.height()
        } else {
            val m = DisplayMetrics()
            @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(m)
            m.widthPixels to m.heightPixels
        }
    }

    private fun newReader(w: Int, h: Int): ImageReader =
        ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3).also { r ->
            r.setOnImageAvailableListener({ rd ->
                val img = try { rd.acquireLatestImage() } catch (e: Exception) { null } ?: return@setOnImageAvailableListener
                synchronized(lock) { last?.close(); last = img }
            }, handler)
        }

    /** Panggil saat layar berputar. */
    fun resize() {
        val (w, h) = screenSize()
        synchronized(lock) { last?.close(); last = null }
        val old = reader
        reader = newReader(w, h)
        display.resize(w, h, dpi)
        display.surface = reader.surface
        old.close()
    }

    fun grab(): Bitmap? = synchronized(lock) {
        val img = last ?: return null
        val plane = img.planes[0]
        val pw = plane.rowStride / plane.pixelStride
        val bm = Bitmap.createBitmap(pw, img.height, Bitmap.Config.ARGB_8888)
        bm.copyPixelsFromBuffer(plane.buffer)
        if (pw != img.width) Bitmap.createBitmap(bm, 0, 0, img.width, img.height) else bm
    }

    fun release() {
        synchronized(lock) { last?.close(); last = null }
        display.release()
        reader.close()
        handler.looper.quitSafely()
    }
}
