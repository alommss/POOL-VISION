package com.poolvision.overlay

import android.graphics.Bitmap
import android.graphics.PointF
import android.graphics.RectF
import kotlin.math.roundToInt

enum class Kind { CUE, EIGHT, OBJECT }
enum class ShotType { STRAIGHT, BANK }

data class Ball(val pos: PointF, val r: Float, val kind: Kind)

data class Scene(
    val cue: Ball?,
    val balls: List<Ball>,      // semua bola selain bola putih
    val pockets: List<PointF>,
    val table: RectF,
    val ballR: Float
)

data class ShotPlan(
    val target: Ball,
    val pocket: PointF,
    val ghost: PointF,          // posisi bola putih saat menyentuh target
    val bounce: PointF?,        // titik pantulan bantalan (jika BANK)
    val cutDeg: Float,
    val aimDeg: Float,          // 0° = kanan, searah jarum jam
    val type: ShotType,
    val power: String
) {
    fun describe(): String {
        val t = if (target.kind == Kind.EIGHT) "Bola 8" else "Bola target"
        val s = if (type == ShotType.STRAIGHT) "Lurus" else "Pantulan 1 bantalan"
        return "$t • $s • Sudut ${aimDeg.roundToInt()}° • Potongan ${cutDeg.roundToInt()}° • Tenaga $power"
    }
}

/** Penyimpanan hasil analisis terakhir untuk layar analisis. */
object AnalysisStore {
    var bitmap: Bitmap? = null
    var scene: Scene? = null
    var plan: ShotPlan? = null
}
