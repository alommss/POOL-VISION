package com.poolvision.overlay

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot
import kotlin.math.min

class AnalysisView(ctx: Context) : View(ctx) {
    var bitmap: Bitmap? = null
    var scene: Scene? = null
    var plan: ShotPlan? = null
    var onPick: ((Ball) -> Unit)? = null

    private val neon = Color.parseColor("#00E5FF")
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = neon; style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val dash = Paint(line).apply { color = Color.parseColor("#7700E5FF") }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private var scale = 1f; private var ox = 0f; private var oy = 0f

    override fun onDraw(c: Canvas) {
        val bmp = bitmap ?: return
        val sc = scene
        scale = min(width / bmp.width.toFloat(), height / bmp.height.toFloat())
        ox = (width - bmp.width * scale) / 2; oy = (height - bmp.height * scale) / 2
        c.drawColor(Color.BLACK)
        c.save(); c.translate(ox, oy); c.scale(scale, scale)
        c.drawBitmap(bmp, 0f, 0f, null)
        c.drawColor(0x88000000.toInt())
        if (sc == null) { c.restore(); return }

        val r = sc.ballR
        line.strokeWidth = r * 0.28f
        dash.strokeWidth = r * 0.2f
        dash.pathEffect = DashPathEffect(floatArrayOf(r, r * 0.7f), 0f)
        ring.strokeWidth = r * 0.18f

        ring.color = Color.parseColor("#4400E5FF")
        c.drawRect(sc.table, ring)
        sc.pockets.forEach { c.drawCircle(it.x, it.y, r * 1.5f, ring) }

        for (b in sc.balls) {
            ring.color = if (b.kind == Kind.EIGHT) Color.RED else Color.parseColor("#88FFFFFF")
            c.drawCircle(b.pos.x, b.pos.y, b.r, ring)
        }
        sc.cue?.let { ring.color = Color.WHITE; c.drawCircle(it.pos.x, it.pos.y, it.r * 1.1f, ring) }

        val p = plan; val cue = sc.cue
        if (p != null && cue != null) {
            val mid = p.bounce
            if (mid != null) {
                c.drawLine(cue.pos.x, cue.pos.y, mid.x, mid.y, line)
                c.drawLine(mid.x, mid.y, p.ghost.x, p.ghost.y, line)
                ring.color = neon; c.drawCircle(mid.x, mid.y, r * 0.5f, ring)
            } else {
                c.drawLine(cue.pos.x, cue.pos.y, p.ghost.x, p.ghost.y, line)
            }
            ring.color = neon; c.drawCircle(p.ghost.x, p.ghost.y, r, ring)           // ghost ball
            c.drawLine(p.target.pos.x, p.target.pos.y, p.pocket.x, p.pocket.y, dash) // jalur target
            ring.color = Color.GREEN; c.drawCircle(p.target.pos.x, p.target.pos.y, r * 1.25f, ring)
        }
        c.restore()
        txt.textSize = 13f * resources.displayMetrics.density
        c.drawText("Ketuk bola lain untuk menjadikannya target", 24f, height - 24f, txt)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action == MotionEvent.ACTION_UP) {
            val sc = scene ?: return true
            val x = (e.x - ox) / scale; val y = (e.y - oy) / scale
            sc.balls.minByOrNull { hypot(it.pos.x - x, it.pos.y - y) }
                ?.takeIf { hypot(it.pos.x - x, it.pos.y - y) < sc.ballR * 3 }
                ?.let { onPick?.invoke(it) }
        }
        return true
    }
}
