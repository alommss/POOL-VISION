package com.poolvision.overlay

import android.Manifest
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private val neon = Color.parseColor("#00E5FF")
    private lateinit var status: TextView

    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
            val data = res.data
            if (res.resultCode == RESULT_OK && data != null) {
                ContextCompat.startForegroundService(
                    this,
                    Intent(this, OverlayService::class.java)
                        .putExtra(OverlayService.EXTRA_CODE, res.resultCode)
                        .putExtra(OverlayService.EXTRA_DATA, data)
                )
                moveTaskToBack(true)   // buka 8 Ball Pool, tombol melayang sudah aktif
            } else Toast.makeText(this, "Izin tangkap layar ditolak", Toast.LENGTH_SHORT).show()
        }
    private val notifLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)

        fun btn(t: String, f: () -> Unit) = Button(this).apply {
            text = t; setTextColor(Color.BLACK); setOnClickListener { f() }
            background = GradientDrawable().apply { cornerRadius = 40f; setColor(neon) }
        }
        status = TextView(this).apply { setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(0, 24, 0, 24) }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(64, 64, 64, 64); setBackgroundColor(Color.BLACK)
            addView(TextView(context).apply {
                text = "POOL VISION\nOVERLAY AI"; textSize = 28f; setTextColor(neon); gravity = Gravity.CENTER
            })
            addView(status)
            addView(btn("1. Izinkan Tampil di Atas Aplikasi Lain") {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            })
            addView(btn("2. Mulai (izin tangkap layar)") {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    Toast.makeText(this@MainActivity, "Berikan izin overlay dulu", Toast.LENGTH_SHORT).show()
                } else {
                    val mpm = getSystemService(MediaProjectionManager::class.java)
                    projectionLauncher.launch(mpm.createScreenCaptureIntent())
                }
            })
        })
    }

    override fun onResume() {
        super.onResume()
        status.text = if (Settings.canDrawOverlays(this)) "Izin overlay: OK" else "Izin overlay: belum diberikan"
    }
}
