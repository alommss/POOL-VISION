package com.poolvision.overlay

import android.graphics.Bitmap
import android.graphics.PointF
import android.graphics.RectF
import org.opencv.android.Utils
import org.opencv.core.*
import org.opencv.imgproc.Imgproc
import android.os.SystemClock
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Computer vision murni dari screenshot: tidak menyentuh proses/memori game.
 * analyze(): analisis penuh (meja, bola). quick(): pembacaan cepat garis bidik + tarikan stik.
 */
object TableAnalyzer {

    /** gapR = jarak ujung stik dari tepi bola putih (satuan jari-jari bola); cuePresence 0..1 = seberapa "putih" posisi bola putih. */
    class Quick(val aimDir: PointF?, val gapR: Float?, val cuePresence: Float)

    fun analyze(src: Bitmap, ignore: List<android.graphics.Rect> = emptyList()): Scene? {
        val mats = ArrayList<Mat>()
        try { return analyzeInternal(src, ignore, mats) } finally { mats.forEach { it.release() } }
    }

    private fun analyzeInternal(src: Bitmap, ignore: List<android.graphics.Rect>, mats: MutableList<Mat>): Scene? {
        val rgba = Mat().also { mats += it }; Utils.bitmapToMat(src, rgba)
        val bgr = Mat().also { mats += it }; Imgproc.cvtColor(rgba, bgr, Imgproc.COLOR_RGBA2BGR)
        val hsv = Mat().also { mats += it }; Imgproc.cvtColor(bgr, hsv, Imgproc.COLOR_BGR2HSV)
        val gray = Mat().also { mats += it }; Imgproc.cvtColor(bgr, gray, Imgproc.COLOR_BGR2GRAY)

        val hue = dominantHue(hsv) ?: return null
        val mask = Mat().also { mats += it }
        Core.inRange(
            hsv,
            Scalar(max(0.0, hue - 14.0), 60.0, 100.0),
            Scalar(min(179.0, hue + 14.0), 255.0, 255.0),
            mask
        )
        for (ig in ignore) Imgproc.rectangle(mask, Point(ig.left.toDouble(), ig.top.toDouble()),
            Point(ig.right.toDouble(), ig.bottom.toDouble()), Scalar(0.0), -1)
        val k = Imgproc.getStructuringElement(Imgproc.MORPH_RECT, Size(9.0, 9.0))
        Imgproc.morphologyEx(mask, mask, Imgproc.MORPH_CLOSE, k)

        val contours = ArrayList<MatOfPoint>()
        val maskCopy = mask.clone().also { mats += it }
        Imgproc.findContours(maskCopy, contours, Mat().also { mats += it }, Imgproc.RETR_EXTERNAL, Imgproc.CHAIN_APPROX_SIMPLE)
        val biggest = contours.maxByOrNull { Imgproc.contourArea(it) } ?: return null
        val rect = Imgproc.boundingRect(biggest)
        if (rect.area() < 0.15 * src.width * src.height) return null
        val ratio = max(rect.width, rect.height).toDouble() / min(rect.width, rect.height)
        if (ratio < 1.5 || ratio > 2.4) return null

        val l = rect.x.toFloat(); val t = rect.y.toFloat()
        val r = (rect.x + rect.width).toFloat(); val b = (rect.y + rect.height).toFloat()
        val table = RectF(l, t, r, b)

        val pockets = mutableListOf(PointF(l, t), PointF(r, t), PointF(l, b), PointF(r, b))
        if (rect.width >= rect.height) {
            pockets += PointF((l + r) / 2, t); pockets += PointF((l + r) / 2, b)
        } else {
            pockets += PointF(l, (t + b) / 2); pockets += PointF(r, (t + b) / 2)
        }

        val roi = Mat().also { mats += it }
        Imgproc.GaussianBlur(gray.submat(rect), roi, Size(5.0, 5.0), 1.5)
        val len = max(rect.width, rect.height).toDouble()
        val minR = (len * 0.010).toInt().coerceAtLeast(4)
        val maxR = (len * 0.019).toInt().coerceAtLeast(minR + 2)
        val circles = Mat().also { mats += it }
        Imgproc.HoughCircles(roi, circles, Imgproc.HOUGH_GRADIENT, 1.0, minR * 1.7, 110.0, 18.0, minR, maxR)

        data class C(val x: Float, val y: Float, val rad: Float)
        val found = ArrayList<C>()
        for (i in 0 until circles.cols()) {
            val c = circles.get(0, i) ?: continue
            found += C(c[0].toFloat() + rect.x, c[1].toFloat() + rect.y, c[2].toFloat())
        }
        if (found.isEmpty()) return null

        val ballR = found.map { it.rad }.sorted()[found.size / 2]
        val white = Mat().also { mats += it }
        Core.inRange(hsv, Scalar(0.0, 0.0, 175.0), Scalar(179.0, 60.0, 255.0), white)

        var cue: Ball? = null
        var cueW = 0.7
        val others = ArrayList<Ball>()
        for (c in found) {
            if (pockets.any { hypot(c.x - it.x, c.y - it.y) < ballR * 2.2f }) continue
            if (ignore.any { it.contains(c.x.toInt(), c.y.toInt()) }) continue

            val rr = (c.rad * 0.8).toInt().coerceAtLeast(2)
            val x0 = (c.x - rr).toInt().coerceAtLeast(0); val y0 = (c.y - rr).toInt().coerceAtLeast(0)
            val x1 = min(hsv.cols(), (c.x + rr).toInt() + 1); val y1 = min(hsv.rows(), (c.y + rr).toInt() + 1)
            if (x1 - x0 < 3 || y1 - y0 < 3) continue
            val box = Rect(x0, y0, x1 - x0, y1 - y0)
            val m = Mat.zeros(box.size(), CvType.CV_8UC1)
            Imgproc.circle(m, Point(c.x - x0.toDouble(), c.y - y0.toDouble()), rr, Scalar(255.0), -1)

            val mean = Core.mean(hsv.submat(box), m)
            val mu = MatOfDouble(); val sd = MatOfDouble()
            Core.meanStdDev(gray.submat(box), mu, sd, m)
            val std = sd.get(0, 0)[0]
            val wm = Mat(); Core.bitwise_and(white.submat(box), m, wm)
            val total = Core.countNonZero(m).coerceAtLeast(1)
            val wf = Core.countNonZero(wm).toDouble() / total
            var col = 0
            run {
                val bgrBox = bgr.submat(box)
                val nw = Mat(); Core.bitwise_not(white.submat(box), nw); Core.bitwise_and(nw, m, nw)
                if (Core.countNonZero(nw) >= 6) {
                    val mc = Core.mean(bgrBox, nw)
                    col = ballColor(mc.`val`[2], mc.`val`[1], mc.`val`[0])
                }
                nw.release(); bgrBox.release()
            }
            m.release(); wm.release(); mu.release(); sd.release()

            if (abs(mean.`val`[0] - hue) <= 10 && std < 10 && wf < 0.15) continue

            val pos = PointF(c.x, c.y)
            when {
                wf > cueW -> { cueW = wf; cue = Ball(pos, ballR, Kind.CUE) }
                mean.`val`[2] < 75 -> others += Ball(pos, ballR, Kind.EIGHT, color = 0xFFB4B4B4.toInt())
                else -> others += Ball(pos, ballR, Kind.OBJECT, stripe = wf > 0.22, color = col)
            }
        }
        val aim = cue?.let { scanAim(hsv.submat(rect).also { m -> mats += m }, rect, it, null) }
        return Scene(cue, others, pockets, table, ballR, aim, hue)
    }

    /**
     * Pembacaan cepat (±20-30x/detik): arah garis bidik game, tarikan stik, dan apakah bola putih
     * masih berada di posisinya. prevAim dipakai untuk memilih garis yang sama dengan frame sebelumnya.
     */
    fun quick(src: Bitmap, sc: Scene, prevAim: PointF? = null): Quick? {
        val cue = sc.cue ?: return null
        val rect = tableRect(src, sc) ?: return null
        val mats = ArrayList<Mat>()
        try {
            val rgba = Mat().also { mats += it }; Utils.bitmapToMat(src, rgba)
            val roi = rgba.submat(rect).also { mats += it }
            val bgr = Mat().also { mats += it }; Imgproc.cvtColor(roi, bgr, Imgproc.COLOR_RGBA2BGR)
            val hsv = Mat().also { mats += it }; Imgproc.cvtColor(bgr, hsv, Imgproc.COLOR_BGR2HSV)
            val presence = cuePresence(hsv, rect, cue)
            if (presence < 0.4f) return Quick(null, null, presence)
            val aim = scanAim(hsv, rect, cue, prevAim)
            val gap = aim?.let { measureGapR(hsv, rect, cue, it, sc.hue) }
            return Quick(aim, gap, presence)
        } finally { mats.forEach { it.release() } }
    }

    private fun tableRect(src: Bitmap, sc: Scene): Rect? {
        val tb = sc.table
        val x0 = tb.left.toInt().coerceAtLeast(0); val y0 = tb.top.toInt().coerceAtLeast(0)
        val x1 = min(src.width, tb.right.toInt()); val y1 = min(src.height, tb.bottom.toInt())
        if (x1 - x0 < 50 || y1 - y0 < 50) return null
        return Rect(x0, y0, x1 - x0, y1 - y0)
    }

    // ---- deteksi gerakan (untuk tahu kapan semua bola sudah berhenti) ----
    private var refSmall: Mat? = null
    private var refAt = 0L

    fun resetMotion() { refSmall?.release(); refSmall = null; refAt = 0L }

    /** Fraksi piksel meja yang berubah dibanding ±200 ms lalu. null = belum ada pembanding. */
    fun motion(src: Bitmap, sc: Scene): Float? {
        val rect = tableRect(src, sc) ?: return null
        val rgba = Mat(); val gray = Mat(); val small = Mat()
        try {
            Utils.bitmapToMat(src, rgba)
            val roi = rgba.submat(rect)
            Imgproc.cvtColor(roi, gray, Imgproc.COLOR_RGBA2GRAY)
            roi.release()
            Imgproc.resize(gray, small, Size(rect.width / 6.0, rect.height / 6.0), 0.0, 0.0, Imgproc.INTER_AREA)
            val now = SystemClock.uptimeMillis()
            val ref = refSmall
            if (ref == null || ref.rows() != small.rows() || ref.cols() != small.cols()) {
                ref?.release(); refSmall = small.clone(); refAt = now
                return null
            }
            val diff = Mat()
            Core.absdiff(small, ref, diff)
            Imgproc.threshold(diff, diff, 14.0, 255.0, Imgproc.THRESH_BINARY)
            val frac = Core.countNonZero(diff).toFloat() / (small.rows() * small.cols()).coerceAtLeast(1)
            diff.release()
            if (now - refAt >= 200L) { ref.release(); refSmall = small.clone(); refAt = now }
            return frac
        } finally { rgba.release(); gray.release(); small.release() }
    }

    /** Seberapa banyak piksel "putih bola" di dalam lingkaran kecil di posisi bola putih (0..1). */
    private fun cuePresence(hsv: Mat, rect: Rect, cue: Ball): Float {
        val rr = cue.r * 0.75f
        var total = 0; var white = 0
        var dy = -rr
        while (dy <= rr) {
            var dx = -rr
            while (dx <= rr) {
                if (dx * dx + dy * dy <= rr * rr) {
                    val x = (cue.pos.x + dx - rect.x).toInt(); val y = (cue.pos.y + dy - rect.y).toInt()
                    if (x >= 0 && y >= 0 && x < hsv.cols() && y < hsv.rows()) {
                        val p = hsv.get(y, x)
                        if (p != null) { total++; if (p[1] <= 70 && p[2] >= 160) white++ }
                    }
                }
                dx += 2f
            }
            dy += 2f
        }
        return if (total == 0) 0f else white.toFloat() / total
    }

    private fun angDiff(a: Double, b: Double): Double {
        var d = a - b
        while (d > Math.PI) d -= 2 * Math.PI
        while (d < -Math.PI) d += 2 * Math.PI
        return abs(d)
    }

    /**
     * Arah garis bidik game: sinar dipindai dari PUSAT bola putih (kasar 0,5° lalu dihaluskan 0,05°),
     * mencari garis putih tipis yang menyambung dari bola. Hasilnya selalu tepat lewat pusat bola dan
     * jauh lebih halus/cepat daripada HoughLinesP di seluruh meja.
     */
    private fun scanAim(hsv: Mat, rect: Rect, cue: Ball, prev: PointF?): PointF? {
        val w = hsv.cols(); val h = hsv.rows()
        val m = Mat(); val md = Mat()
        val kernel = Imgproc.getStructuringElement(Imgproc.MORPH_RECT, Size(3.0, 3.0))
        try {
            Core.inRange(hsv, Scalar(0.0, 0.0, 215.0), Scalar(179.0, 45.0, 255.0), m)
            Imgproc.dilate(m, md, kernel)
            val buf = ByteArray(w * h)
            md.get(0, 0, buf)
            return scanRays(buf, w, h, cue.pos.x - rect.x, cue.pos.y - rect.y, cue.r, prev)
        } finally { m.release(); md.release(); kernel.release() }
    }

    private fun scanRays(buf: ByteArray, w: Int, h: Int, cx: Float, cy: Float, r: Float, prev: PointF?): PointF? {
        fun hit(x: Float, y: Float): Boolean {
            if (x < 0f || y < 0f) return false
            val xi = x.toInt(); val yi = y.toInt()
            if (xi >= w || yi >= h) return false
            return buf[yi * w + xi].toInt() != 0
        }
        val step = 1.5f
        val s0 = r * 1.25f
        val sShort = s0 + r * 4f
        val nShort = ((sShort - s0) / step).toInt() + 1
        val maxS = hypot(w.toFloat(), h.toFloat()) * 0.9f

        // 1) pindai kasar 720 arah pada jarak dekat dari bola
        val n = 720
        val score = IntArray(n)
        for (i in 0 until n) {
            val a = Math.toRadians(i * 0.5)
            val ca = cos(a).toFloat(); val sa = sin(a).toFloat()
            var cnt = 0; var s = s0
            while (s <= sShort) { if (hit(cx + ca * s, cy + sa * s)) cnt++; s += step }
            score[i] = cnt
        }
        val thr = (nShort * 0.8f).toInt().coerceAtLeast(8)
        val base = (0 until n).firstOrNull { score[it] < thr } ?: return null
        val cands = ArrayList<Double>()
        var clStart = -1
        for (j in 1..n) {
            val k = (base + j) % n
            if (score[k] >= thr) {
                if (clStart < 0) clStart = j
            } else if (clStart >= 0) {
                val mid = (clStart + j - 1) / 2.0
                cands += Math.toRadians(((base + mid) % n) * 0.5)
                clStart = -1
            }
        }
        if (cands.isEmpty()) return null

        fun runEnd(a: Double): Float {
            val ca = cos(a).toFloat(); val sa = sin(a).toFloat()
            var s = s0; var last = s0; var miss = 0
            while (s < maxS) {
                if (hit(cx + ca * s, cy + sa * s)) { last = s; miss = 0 }
                else if (++miss > 5) break
                s += step
            }
            return last
        }
        fun hits(a: Double, to: Float): Int {
            val ca = cos(a).toFloat(); val sa = sin(a).toFloat()
            var cnt = 0; var s = s0
            while (s <= to) { if (hit(cx + ca * s, cy + sa * s)) cnt++; s += step }
            return cnt
        }

        // 2) haluskan tiap kandidat memakai seluruh panjang garis (±1,2°, langkah 0,05°)
        val refined = ArrayList<Pair<Double, Float>>()
        for (c0 in cands.take(8)) {
            val end0 = runEnd(c0)
            if (end0 < s0 + r * 6f) continue
            val angs = ArrayList<Double>(); val sc = ArrayList<Int>()
            var best = -1
            var d = -1.2
            while (d <= 1.2001) {
                val a = c0 + Math.toRadians(d)
                val v = hits(a, end0)
                angs += a; sc += v
                if (v > best) best = v
                d += 0.05
            }
            var sum = 0.0; var cnt = 0
            for (i in angs.indices) if (sc[i] >= best * 0.98) { sum += angs[i]; cnt++ }
            val ang = sum / cnt
            refined += Pair(ang, runEnd(ang))
        }
        if (refined.isEmpty()) return null

        // 3) pilih: yang paling dekat dengan arah frame sebelumnya (stik digeser pelan), kalau tidak ada yang panjang
        val prevAng = prev?.let { atan2(it.y.toDouble(), it.x.toDouble()) }
        val longest = refined.maxByOrNull { it.second }!!
        val pick = if (prevAng != null) {
            val near = refined.minByOrNull { angDiff(it.first, prevAng) }!!
            if (angDiff(near.first, prevAng) <= Math.toRadians(25.0)) near else longest
        } else longest
        return PointF(cos(pick.first).toFloat(), sin(pick.first).toFloat())
    }

    /** Jarak ujung stik dari tepi bola putih (satuan r), ditelusuri berlawanan arah bidikan dengan 3 sinar sejajar. */
    private fun measureGapR(hsv: Mat, rect: Rect, cue: Ball, dir: PointF, hue: Int): Float? {
        val r = cue.r
        val maxS = max(rect.width, rect.height) * 0.30f
        val px = -dir.y; val py = dir.x
        val offs = floatArrayOf(-0.3f, 0f, 0.3f)
        var s = r * 1.1f
        var run = 0
        var firstS = 0f
        while (s < maxS) {
            var non = 0
            for (o in offs) {
                val x = (cue.pos.x - dir.x * s + px * o * r - rect.x).toInt()
                val y = (cue.pos.y - dir.y * s + py * o * r - rect.y).toInt()
                if (x < 0 || y < 0 || x >= hsv.cols() || y >= hsv.rows()) return null
                val p = hsv.get(y, x) ?: continue
                val felt = abs(p[0] - hue) <= 15 && p[1] > 50
                if (!felt) non++
            }
            if (non >= 2) {
                if (run == 0) firstS = s
                run++
                if (run >= 4) return ((firstS - r) / r).coerceAtLeast(0f)
            } else run = 0
            s += 1.5f
        }
        return null
    }

    /** Warna bola (rata-rata piksel non-putih) dibuat lebih terang/jenuh agar garis terlihat jelas di atas meja. */
    private fun ballColor(r: Double, g: Double, b: Double): Int {
        val hsv = FloatArray(3)
        android.graphics.Color.RGBToHSV(r.toInt().coerceIn(0, 255), g.toInt().coerceIn(0, 255), b.toInt().coerceIn(0, 255), hsv)
        if (hsv[2] < 0.25f && hsv[1] < 0.3f) return 0xFFB4B4B4.toInt()
        if (hsv[1] > 0.15f) hsv[1] = max(hsv[1], 0.7f)
        hsv[2] = max(hsv[2], 0.95f)
        return android.graphics.Color.HSVToColor(hsv)
    }

    private fun dominantHue(hsv: Mat): Int? {
        val hist = IntArray(180)
        val x0 = hsv.cols() / 5; val x1 = hsv.cols() * 4 / 5
        val y0 = hsv.rows() / 5; val y1 = hsv.rows() * 4 / 5
        for (y in y0 until y1 step 6) for (x in x0 until x1 step 6) {
            val p = hsv.get(y, x) ?: continue
            if (p[1] > 70 && p[2] > 100) hist[p[0].toInt().coerceIn(0, 179)]++
        }
        val best = hist.indices.maxByOrNull { hist[it] } ?: return null
        return if (hist[best] > 50) best else null
    }
}
