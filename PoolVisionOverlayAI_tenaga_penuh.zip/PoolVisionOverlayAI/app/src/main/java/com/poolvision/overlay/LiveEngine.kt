package com.poolvision.overlay

import android.graphics.PointF
import android.graphics.Rect
import android.os.SystemClock
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin
import kotlin.math.sqrt

/** Pengaturan dari panel; dibaca engine di setiap siklus. */
class LiveSettings {
    @Volatile var enabled = true
    @Volatile var group = Group.ALL
    @Volatile var useGameLine = true
}

/** Arah bidik -> jalur semua bola, SELALU dengan tenaga penuh (energi & bantalan dipelajari otomatis). */
object PathBuilder {
    fun build(sc: Scene, plan: ShotPlan?, aim: PointF?, set: LiveSettings, calib: Calibration): List<TrajPath> {
        if (sc.cue == null) return emptyList()
        val dir = (if (set.useGameLine) aim else null) ?: TrajectorySim.dirFromPlan(sc, plan) ?: return emptyList()
        return TrajectorySim.simulate(sc, dir, calib.energyR() * sc.ballR, calib.cushionF())
    }
}

/**
 * Mesin live: SCAN (analisis penuh meja) -> AIM (baca arah stik ±20-30x/detik, gambar prediksi)
 * -> MOVE (pukulan dilepas: prediksi ditahan sampai semua bola berhenti) -> SCAN lagi.
 * Setiap pukulan penuh dipakai untuk belajar otomatis energi dan pantulan bantalan.
 */
class LiveEngine(
    private val capture: ScreenCapture,
    private val calib: Calibration,
    private val set: LiveSettings,
    private val ui: Ui
) {
    interface Ui {
        fun setLineVisible(visible: Boolean)
        fun draw(scene: Scene?, plan: ShotPlan?, paths: List<TrajPath>, skipFirstLeg: Boolean)
        fun status(text: String)
        fun ignoreRects(): List<Rect>
    }

    private enum class St { SCAN, AIM, MOVE }

    private class Shot(val dir: PointF, val gap: Float, val scene: Scene)

    @Volatile private var running = false
    @Volatile private var replanRequested = false
    private var thread: Thread? = null

    private var st = St.SCAN
    private var scene: Scene? = null
    private var plan: ShotPlan? = null
    private var nextScanAt = 0L
    private var lastScanAt = 0L
    private var wasDisabled = false

    private var aim: PointF? = null
    private var aimAt = 0L
    private var gapR: Float? = null
    private var gapAt = 0L
    private val recentGaps = ArrayList<Pair<Long, Float>>()
    private var maxGap = 0f

    private var shot: Shot? = null
    private var moveAt = 0L
    private var still = 0
    private var lastSay = ""

    fun start() {
        if (running) return
        running = true
        thread = Thread({ loop() }, "pv-engine").also { it.isDaemon = true; it.start() }
    }

    fun stop() {
        running = false
        thread?.interrupt(); thread = null
        TableAnalyzer.resetMotion()
    }

    fun replan() { replanRequested = true }

    private fun say(t: String) { if (t != lastSay) { lastSay = t; ui.status(t) } }

    private fun loop() {
        TableAnalyzer.resetMotion()
        while (running) {
            val t0 = SystemClock.uptimeMillis()
            try {
                if (!set.enabled) {
                    if (!wasDisabled) { wasDisabled = true; ui.draw(null, null, emptyList(), false) }
                    Thread.sleep(200)
                    continue
                }
                if (wasDisabled) { wasDisabled = false; st = St.SCAN; nextScanAt = 0L }
                when (st) {
                    St.SCAN -> scanStep()
                    St.AIM -> aimStep()
                    St.MOVE -> moveStep()
                }
            } catch (e: InterruptedException) {
                break
            } catch (e: Throwable) {
                say("Kesalahan: ${e.javaClass.simpleName}")
                try { Thread.sleep(300) } catch (_: InterruptedException) { break }
            }
            val dt = SystemClock.uptimeMillis() - t0
            if (dt < 12) try { Thread.sleep(12 - dt) } catch (_: InterruptedException) { break }
        }
    }

    // ------------------------------------------------------------------ SCAN

    private fun scanStep() {
        val now = SystemClock.uptimeMillis()
        if (now < nextScanAt) { Thread.sleep(40); return }
        ui.setLineVisible(false)
        Thread.sleep(140)
        val bmp = capture.grab()
        ui.setLineVisible(true)
        if (bmp == null) { say("Gagal ambil layar."); nextScanAt = SystemClock.uptimeMillis() + 600; return }

        val sc = try { TableAnalyzer.analyze(bmp, ui.ignoreRects()) } catch (e: Throwable) { null }
        lastScanAt = SystemClock.uptimeMillis()
        if (sc == null) {
            scene = null; plan = null; resetAim()
            ui.draw(null, null, emptyList(), false)
            say("Meja tidak terdeteksi.")
            nextScanAt = lastScanAt + 900
            return
        }
        val note = resolveShot(sc)
        scene = sc
        plan = AimCalculator.plan(sc, null, set.group)
        resetAim()
        if (sc.cue == null) {
            ui.draw(sc, plan, emptyList(), false)
            say("Bola putih tidak terlihat.")
            nextScanAt = lastScanAt + 800
            return
        }
        TableAnalyzer.resetMotion()
        st = St.AIM
        say(listOfNotNull(note, plan?.describe() ?: "Tidak ada bidikan jelas.").joinToString("\n"))
    }

    private fun resetAim() { aim = null; gapR = null; recentGaps.clear() }

    // ------------------------------------------------------------------ AIM

    private fun smoothDir(prev: PointF?, raw: PointF): PointF {
        if (prev == null) return raw
        val a0 = atan2(prev.y.toDouble(), prev.x.toDouble())
        val a1 = atan2(raw.y.toDouble(), raw.x.toDouble())
        var d = a1 - a0
        while (d > Math.PI) d -= 2 * Math.PI
        while (d < -Math.PI) d += 2 * Math.PI
        val k = if (abs(d) > Math.toRadians(1.5)) 1.0 else 0.55
        val a = a0 + d * k
        return PointF(cos(a).toFloat(), sin(a).toFloat())
    }

    private fun aimStep() {
        val sc = scene
        if (sc == null || sc.cue == null) { st = St.SCAN; return }
        if (replanRequested) { replanRequested = false; plan = AimCalculator.plan(sc, null, set.group) }

        val bmp = capture.grabShared()
        if (bmp == null) { Thread.sleep(30); return }
        val now = SystemClock.uptimeMillis()
        val q = TableAnalyzer.quick(bmp, sc, aim)
        if (q == null) { Thread.sleep(30); return }

        // bola putih sudah pergi dari tempatnya -> pukulan dilepas
        if (q.cuePresence < 0.40f) { onCueMoved(sc, now); return }

        val rawAim = q.aimDir
        if (rawAim != null) { aim = smoothDir(aim, rawAim); aimAt = now }

        val rawGap = q.gapR
        if (rawGap != null) {
            val g = gapR
            gapR = if (g == null || now - gapAt > 600L) rawGap else g + (rawGap - g) * 0.6f
            gapAt = now
            val v = gapR ?: rawGap
            if (v > maxGap) maxGap = v
            recentGaps += Pair(now, v)
            while (recentGaps.isNotEmpty() && now - recentGaps[0].first > 1000L) recentGaps.removeAt(0)
        }

        if ((aim == null || now - aimAt > 1500L) && now - lastScanAt > 15000L) { st = St.SCAN; nextScanAt = 0L; return }

        val dirNow = if (aim != null && now - aimAt <= 600L) aim else null
        val paths = PathBuilder.build(sc, plan, dirNow, set, calib)
        ui.draw(sc, plan, paths, set.useGameLine && dirNow != null)
    }

    private fun onCueMoved(sc: Scene, now: Long) {
        val d = aim
        val peak = recentGaps.maxByOrNull { it.second }?.second ?: 0f
        shot = if (d != null && now - aimAt <= 1500L) Shot(d, peak, sc) else null
        resetAim()
        st = St.MOVE; moveAt = now; still = 0
        TableAnalyzer.resetMotion()
        say("Bola bergerak… prediksi ditahan.")
    }

    // ------------------------------------------------------------------ MOVE

    private fun moveStep() {
        val sc = scene
        if (sc == null) { st = St.SCAN; return }
        val bmp = capture.grabShared()
        if (bmp == null) { Thread.sleep(40); return }
        val m = TableAnalyzer.motion(bmp, sc)
        if (m != null) { if (m < 0.0006f) still++ else still = 0 }
        Thread.sleep(40)
        val elapsed = SystemClock.uptimeMillis() - moveAt
        if ((still >= 6 && elapsed >= 700L) || elapsed > 9000L) {
            TableAnalyzer.resetMotion()
            st = St.SCAN; nextScanAt = 0L
        }
    }

    // ------------------------------------------------------------------ belajar otomatis

    /**
     * Cari energi E (dan faktor bantalan c) yang membuat simulasi menghentikan bola putih persis di
     * tempat berhentinya yang NYATA. Dilewati bila tarikan stik jelas bukan penuh, hasil tidak cocok,
     * atau ambigu (mis. bola putih berhenti mati setelah menabrak).
     */
    private fun resolveShot(nw: Scene): String? {
        val s = shot ?: return null
        shot = null
        val cue = nw.cue ?: return null
        val r = s.scene.ballR
        val c0 = s.scene.cue ?: return null
        if (hypot(cue.pos.x - c0.pos.x, cue.pos.y - c0.pos.y) < r) return null
        if (maxGap > 0f && s.gap < maxGap * 0.8f) return "Belajar: bukan tenaga penuh, dilewati."

        fun err(e: Double, c: Float): Float {
            val p = TrajectorySim.simulate(s.scene, s.dir, (e * r).toFloat(), c).firstOrNull() ?: return 1e9f
            if (p.pocketed) return 1e9f
            val end = p.pts.last()
            return hypot(end.x - cue.pos.x, end.y - cue.pos.y) / r
        }

        var bestE = 3.0; var bestC = 0.72f; var bestErr = Float.MAX_VALUE
        for (c in floatArrayOf(0.55f, 0.65f, 0.72f, 0.8f, 0.88f)) {
            var e = 3.0
            while (e <= 900.0) {
                val v = err(e, c)
                if (v < bestErr) { bestErr = v; bestE = e; bestC = c }
                e *= 1.06
            }
        }
        var f = bestE / 1.06
        while (f <= bestE * 1.06) { val v = err(f, bestC); if (v < bestErr) { bestErr = v; bestE = f }; f *= 1.004 }
        for (dc in floatArrayOf(-0.04f, -0.02f, 0.02f, 0.04f)) {
            val c = (bestC + dc).coerceIn(0.4f, 0.95f)
            var g = bestE / 1.03
            while (g <= bestE * 1.03) { val v = err(g, c); if (v < bestErr) { bestErr = v; bestE = g; bestC = c }; g *= 1.004 }
        }
        if (bestErr > 1.5f) return "Belajar: hasil nyata tak cocok simulasi, dilewati."

        var lo = bestE; while (lo > 1.0 && err(lo / 1.01, bestC) <= 1.0f) lo /= 1.01
        var hi = bestE; while (hi < 1800.0 && err(hi * 1.01, bestC) <= 1.0f) hi *= 1.01
        if (hi / lo > 1.3) return "Belajar: hasil ambigu, dilewati."
        return calib.addSample(sqrt(lo * hi).toFloat(), bestC, calib.energyR())
    }
}
