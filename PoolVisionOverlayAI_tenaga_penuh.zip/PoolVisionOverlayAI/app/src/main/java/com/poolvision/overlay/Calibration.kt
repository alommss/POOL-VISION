package com.poolvision.overlay

import android.content.Context
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.roundToInt

/**
 * Hanya pukulan kekuatan penuh, jadi cukup dua konstanta yang dipelajari otomatis dari hasil nyata:
 *  - energi = jarak tempuh bola putih pada tenaga penuh (satuan jari-jari bola, r)
 *  - cushion = sisa energi setelah memantul di bantalan (0..1)
 * Disimpan permanen; tiap pukulan memperbaikinya (median dari 15 pukulan terakhir).
 */
class Calibration(ctx: Context) {
    companion object {
        const val E_PRIOR = 276f
        const val C_PRIOR = 0.72f
        private const val MAX_SAMPLES = 15
    }

    private val prefs = ctx.getSharedPreferences("pv_calib_full", Context.MODE_PRIVATE)
    private val es = ArrayList<Float>()
    private val cs = ArrayList<Float>()
    @Volatile private var energy = E_PRIOR
    @Volatile private var cushion = C_PRIOR

    init {
        energy = prefs.getFloat("e", E_PRIOR); cushion = prefs.getFloat("c", C_PRIOR)
        prefs.getString("s", "")?.split(";")?.forEach {
            val p = it.split(":")
            if (p.size == 2) {
                val e = p[0].toFloatOrNull(); val c = p[1].toFloatOrNull()
                if (e != null && c != null && e > 0f) { es += e; cs += c }
            }
        }
    }

    fun energyR(): Float = energy
    fun cushionF(): Float = cushion
    fun percent(): Int = (energy / E_PRIOR * 100f).roundToInt()
    @Synchronized fun samples(): Int = es.size

    @Synchronized
    fun addSample(eR: Float, c: Float, predictedR: Float): String {
        if (es.size >= 3 && (eR / energy > 2f || eR / energy < 0.5f))
            return "Belajar: hasil janggal (aktual ${eR.roundToInt()} r vs model ${predictedR.roundToInt()} r), dilewati."
        es += eR; cs += c
        while (es.size > MAX_SAMPLES) { es.removeAt(0); cs.removeAt(0) }
        refit(); save()
        return "Belajar otomatis: model ${predictedR.roundToInt()} r → nyata ${eR.roundToInt()} r • ${es.size} pukulan"
    }

    @Synchronized fun nudge(f: Float) {
        energy = (energy * f).coerceIn(20f, 2000f)
        for (i in es.indices) es[i] = es[i] * f
        save()
    }

    @Synchronized fun reset() { es.clear(); cs.clear(); energy = E_PRIOR; cushion = C_PRIOR; save() }

    private fun refit() {
        val n = es.size
        if (n == 0) return
        val w = n / (n + 0.5)
        val le = es.map { ln(it.toDouble()) }.sorted()[n / 2]
        val c = cs.sorted()[n / 2]
        energy = exp((1 - w) * ln(E_PRIOR.toDouble()) + w * le).toFloat().coerceIn(20f, 2000f)
        cushion = ((1 - w) * C_PRIOR + w * c).toFloat().coerceIn(0.3f, 0.95f)
    }

    private fun save() {
        val s = es.indices.joinToString(";") { "${es[it]}:${cs[it]}" }
        prefs.edit().putFloat("e", energy).putFloat("c", cushion).putString("s", s).apply()
    }
}
